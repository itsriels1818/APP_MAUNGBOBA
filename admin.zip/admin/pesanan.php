<?php

include '../config/koneksi.php';

/* SEARCH */

$cari = mysqli_real_escape_string(
$conn,
$_GET['cari'] ?? ''
);
$status =
isset($_GET['status'])
? $_GET['status']
: 'semua';

/* DATA PESANAN */
/* SUMMARY */

$totalSemua = mysqli_num_rows(
mysqli_query($conn,"
SELECT *
FROM pesanan
")
);

$totalMenunggu = mysqli_num_rows(
mysqli_query($conn,"
SELECT *
FROM pesanan
WHERE status_pesanan='menunggu'
")
);

$totalDiproses = mysqli_num_rows(
mysqli_query($conn,"
SELECT *
FROM pesanan
WHERE status_pesanan='diproses'
")
);

$totalSelesai = mysqli_num_rows(
mysqli_query($conn,"
SELECT *
FROM pesanan
WHERE status_pesanan='selesai'
")
);
$where = "
(
nama_pemesan LIKE '%$cari%'
OR id_pesanan LIKE '%$cari%'
)
";

if($status != 'semua'){

$where .= "
AND status_pesanan='$status'
";

}

$pesanan = mysqli_query($conn,"
SELECT *
FROM pesanan
WHERE $where
ORDER BY id_pesanan DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Pesanan</title>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../assets/css/admin.css">

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar" id="sidebar">

<div class="sidebar-top">

<div class="sidebar-logo">

<div class="logo-icon">

<i class="bi bi-cup-hot-fill"></i>

</div>

<div>

<h3>Kedai</h3>

<p>Maung Boba</p>

</div>

</div>

<div
class="close-sidebar"
id="closeSidebar">

<i class="bi bi-x-lg"></i>

</div>

</div>

<div class="sidebar-profile">

<div class="profile-image">

<i class="bi bi-person-fill"></i>

</div>

<div>

<h4>Admin</h4>

<p>Administrator</p>

</div>

</div>

<ul class="sidebar-menu">

<li>

<a href="index.php">

<i class="bi bi-house-door"></i>

Dashboard

</a>

</li>

<li class="active">

<a href="pesanan.php">

<i class="bi bi-receipt"></i>

Pesanan

</a>

</li>

<li>

<a href="menu.php">

<i class="bi bi-cup-straw"></i>

Menu

</a>

</li>

<li>

<a href="stok.php">

<i class="bi bi-box-seam"></i>

Stok

</a>

</li>

<li>

<a href="laporan.php">

<i class="bi bi-bar-chart"></i>

Laporan

</a>

</li>

</ul>

</div>

<!-- MAIN -->

<div class="main-content">

<!-- TOPBAR -->

<div class="mobile-topbar">

<button id="menuToggle">

<i class="bi bi-list"></i>

</button>

<h2>Pesanan</h2>

<div class="notif-icon">

<i class="bi bi-bell"></i>

<?php
$notif = mysqli_num_rows(
mysqli_query($conn,"
SELECT * FROM pesanan
WHERE status_pesanan='menunggu'
")
);
?>

<span><?php echo $notif; ?></span>

</div>

</div>

<!-- HEADER -->

<div class="welcome-box">

<h2>Pesanan</h2>

<p>
Kelola seluruh pesanan pelanggan
</p>

</div>
<div class="summary-grid">

<div class="summary-card">

<p>Total</p>

<h3>

<?php echo $totalSemua; ?>

</h3>

</div>

<div class="summary-card waiting-card">

<p>Menunggu</p>

<h3>

<?php echo $totalMenunggu; ?>

</h3>

</div>

<div class="summary-card process-card">

<p>Diproses</p>

<h3>

<?php echo $totalDiproses; ?>

</h3>

</div>

<div class="summary-card done-card">

<p>Selesai</p>

<h3>

<?php echo $totalSelesai; ?>

</h3>

</div>

</div>
<!-- SEARCH -->

<form method="GET" class="modern-search">

<i class="bi bi-search"></i>

<input
type="text"
name="cari"
placeholder="Cari pelanggan..."
value="<?php echo $cari; ?>">

</form>
<div class="filter-tabs">

<a
href="?status=semua"
class="<?php
echo $status == 'semua'
? 'active-filter'
: '';
?>">

Semua

</a>

<a
href="?status=menunggu"
class="<?php
echo $status == 'menunggu'
? 'active-filter'
: '';
?>">

Menunggu

</a>

<a
href="?status=diproses"
class="<?php
echo $status == 'diproses'
? 'active-filter'
: '';
?>">

Diproses

</a>

<a
href="?status=selesai"
class="<?php
echo $status == 'selesai'
? 'active-filter'
: '';
?>">

Selesai

</a>

</div>
<!-- ORDER -->

<div class="order-list">

<?php
if(mysqli_num_rows($pesanan) == 0){
?>
<div class="empty-order">
<i class="bi bi-inbox"></i>
<h3>Tidak Ada Pesanan</h3>
<p>Belum ada data yang sesuai pencarian</p>
</div>
<?php
}
?>

<?php while($p = mysqli_fetch_array($pesanan)){ ?>

<div class="order-card">

<div class="order-top">

<h4>

#ORD00<?php
echo $p['id_pesanan'];
?>

</h4>

<?php

$class = 'waiting';

if($p['status_pesanan'] == 'diproses'){
$class = 'process';
}

if($p['status_pesanan'] == 'selesai'){
$class = 'done';
}

?>

<span class="status <?php echo $class; ?>">

<?php
echo ucfirst(
$p['status_pesanan']
);
?>

</span>

</div>

<h5>

<?php
echo $p['nama_pemesan'];
?>

</h5>

<div class="order-total">

Rp<?php
echo number_format(
$p['total_harga']
);
?>

</div>

<div class="order-detail">

<span>Tanggal</span>

<span>

<?php
echo date(
'd M Y H:i',
strtotime($p['tanggal'])
);
?>

</span>

</div>

<?php

$detail = mysqli_query($conn,"
SELECT *
FROM detail_pesanan dp
JOIN menu m
ON dp.id_menu = m.id_menu
WHERE dp.id_pesanan='".$p['id_pesanan']."'
");

?>
<?php

$totalItem = mysqli_num_rows($detail);

?>

<div class="order-detail">

<span>Jumlah Item</span>

<span>

<?php echo $totalItem; ?> Item

</span>

</div>
<div class="order-items">

<?php while($d = mysqli_fetch_array($detail)){ ?>

<div class="item-row">

<div class="item-left">

<img
src="../assets/img/<?php echo $d['gambar']; ?>"
onerror="this.src='../assets/img/no-image.png'">

<div>

<h6>

<?php
echo $d['nama_menu'];
?>

</h6>

<p>

Qty:
<?php
echo $d['qty'];
?>

</p>

<?php if($d['catatan'] != ''){ ?>

<small>

<?php
echo $d['catatan'];
?>

</small>

<?php } ?>

</div>

</div>

<div class="item-price">

Rp<?php
echo number_format(
$d['harga'] * $d['qty']
);
?>

</div>

</div>

<?php } ?>

</div>

<div class="order-action">

<?php
if($p['status_pesanan'] == 'menunggu'){
?>

<a
href="../process/update_status.php?id=<?php echo $p['id_pesanan']; ?>&status=diproses&filter=<?php echo $status; ?>"
class="btn-process update-status">

Diproses

</a>

<?php }elseif($p['status_pesanan'] == 'diproses'){ ?>

<a
href="../process/update_status.php?id=<?php echo $p['id_pesanan']; ?>&status=selesai&filter=<?php echo $status; ?>"
class="btn-done update-status">

Selesai

</a>

<?php } ?>

</div>

</div>

<?php } ?>

</div>

</div>

<!-- BOTTOM NAV -->

<div class="bottom-navbar">

<a href="index.php">

<i class="bi bi-house-door"></i>

<span>Dashboard</span>

</a>

<a
href="pesanan.php"
class="active">

<i class="bi bi-receipt"></i>

<span>Pesanan</span>

</a>

<a href="menu.php">

<i class="bi bi-cup-straw"></i>

<span>Menu</span>

</a>

<a href="laporan.php">

<i class="bi bi-grid"></i>

<span>Lainnya</span>

</a>

</div>

<script>

const menuToggle =
document.getElementById(
'menuToggle'
);

const sidebar =
document.getElementById(
'sidebar'
);

const closeSidebar =
document.getElementById(
'closeSidebar'
);

menuToggle.onclick = () => {

sidebar.classList.add(
'active'
);

}

closeSidebar.onclick = () => {

sidebar.classList.remove(
'active'
);

}

</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

const updateBtn =
document.querySelectorAll(
'.update-status'
);

updateBtn.forEach(btn => {

btn.addEventListener(
'click',
function(e){

e.preventDefault();

const link =
this.getAttribute('href');

Swal.fire({
title: 'Ubah Status Pesanan?',
text: 'Status pesanan akan diperbarui',
icon: 'question',
showCancelButton: true,
confirmButtonText: 'Ya, Update',
cancelButtonText: 'Batal',
confirmButtonColor: '#8a5536'
}).then((result) => {

if(result.isConfirmed){

Swal.fire({
title:'Memproses...',
text:'Mohon tunggu',
allowOutsideClick:false,
didOpen:()=>{
Swal.showLoading();

setTimeout(()=>{
window.location = link;
},1000);

}
});

}

});

}
);

});

</script>

<?php if(isset($_GET['success'])){ ?>

<script>

Swal.fire({
icon:'success',
title:'Berhasil',
text:'Status pesanan berhasil diperbarui',
confirmButtonColor:'#8a5536'
});

</script>

<?php } ?>

</body>
</html>