<?php

include '../config/koneksi.php';

/* FILTER */

$kategori =
isset($_GET['kategori'])
? $_GET['kategori']
: 'semua';

/* QUERY */

$where = "1";

if($kategori != 'semua'){

$where .= "
AND nama_kategori='$kategori'
";

}

$stok = mysqli_query($conn,"
SELECT *
FROM menu
JOIN kategori
ON menu.id_kategori = kategori.id_kategori
WHERE $where
ORDER BY stok ASC
");

$totalHabis = mysqli_num_rows(
mysqli_query($conn,"
SELECT *
FROM menu
WHERE stok <= 0
")
);

$totalMenipis = mysqli_num_rows(
mysqli_query($conn,"
SELECT *
FROM menu
WHERE stok > 0
AND stok <= 5
")
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Kelola Stok</title>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="../assets/css/admin.css">

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar" id="sidebar">

<div class="sidebar-top">

<div class="sidebar-logo">

<div class="logo-icon">

<i class="bi bi-cup-hot-fill"></i>

</div>

<div>

<h3>Kedai</h3>

<p>Maung Boba</p>

</div>

</div>

<div
class="close-sidebar"
id="closeSidebar">

<i class="bi bi-x-lg"></i>

</div>

</div>

<div class="sidebar-profile">

<div class="profile-image">

<i class="bi bi-person-fill"></i>

</div>

<div>

<h4>Admin</h4>

<p>Administrator</p>

</div>

</div>

<ul class="sidebar-menu">

<li>

<a href="index.php">

<i class="bi bi-house-door"></i>

Dashboard

</a>

</li>

<li>

<a href="pesanan.php">

<i class="bi bi-receipt"></i>

Pesanan

</a>

</li>

<li>

<a href="menu.php">

<i class="bi bi-cup-straw"></i>

Menu

</a>

</li>

<li class="active">

<a href="stok.php">

<i class="bi bi-box-seam"></i>

Stok

</a>

</li>

<li>

<a href="laporan.php">

<i class="bi bi-bar-chart"></i>

Laporan

</a>

</li>

</ul>

</div>

<!-- MAIN -->

<div class="main-content">

<div class="mobile-topbar">

<button id="menuToggle">

<i class="bi bi-list"></i>

</button>

<h2>Stok</h2>

<div class="notif-icon">

<i class="bi bi-box-seam"></i>

</div>

</div>

<div class="welcome-box">

<h2>Kelola Stok</h2>

<p>
Pantau stok menu kedai
</p>

</div>

<div class="summary-grid">

<div class="summary-card">

<p>Stok Habis</p>

<h3>
<?php echo $totalHabis; ?>
</h3>

</div>

<div class="summary-card">

<p>Stok Menipis</p>

<h3>
<?php echo $totalMenipis; ?>
</h3>

</div>

</div>
<!-- FILTER -->

<div class="filter-tabs">

<a
href="?kategori=semua"
class="<?php
echo $kategori == 'semua'
? 'active-filter'
: '';
?>">

Semua

</a>

<a
href="?kategori=Minuman"
class="<?php
echo $kategori == 'Minuman'
? 'active-filter'
: '';
?>">

Minuman

</a>

<a
href="?kategori=Makanan"
class="<?php
echo $kategori == 'Makanan'
? 'active-filter'
: '';
?>">

Makanan

</a>

<a
href="?kategori=Promo"
class="<?php
echo $kategori == 'Promo'
? 'active-filter'
: '';
?>">

Promo

</a>

</div>

<!-- STOCK GRID -->

<div class="stock-grid">

<?php if(mysqli_num_rows($stok) == 0){ ?>

<div class="empty-menu">

<i class="bi bi-box-seam"></i>

<h3>Tidak Ada Data Stok</h3>

<p>
Belum ada menu pada kategori ini
</p>

</div>

<?php } ?>

<?php while($s = mysqli_fetch_array($stok)){ ?>

<div class="stock-card">

<div class="stock-image">

<img
src="../assets/img/<?php echo $s['gambar']; ?>"
onerror="this.src='../assets/img/no-image.png'">

</div>

<div class="stock-body">

<div class="stock-top">

<h4>

<?php
echo $s['nama_menu'];
?>

</h4>

<span>

<?php
echo $s['nama_kategori'];
?>

</span>

</div>

<?php

if($s['stok'] <= 0){

?>

<div class="stock-status out">

Stok Habis

</div>

<?php

}elseif($s['stok'] <= 5){

?>

<div class="stock-status low">

Stok Menipis

</div>

<?php }else{ ?>

<div class="stock-status ready">

Stok Aman

</div>

<?php } ?>

<div class="stock-footer">

<h3>

<?php
echo $s['stok'];
?>

</h3>

<a
href="edit_menu.php?id=<?php echo $s['id_menu']; ?>">

Update

</a>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

<!-- BOTTOM NAV -->

<div class="bottom-navbar">

<a href="index.php">

<i class="bi bi-house-door"></i>

<span>Dashboard</span>

</a>

<a href="pesanan.php">

<i class="bi bi-receipt"></i>

<span>Pesanan</span>

</a>

<a href="menu.php">

<i class="bi bi-cup-straw"></i>

<span>Menu</span>

</a>

<a
href="stok.php"
class="active">

<i class="bi bi-grid"></i>

<span>Stok</span>

</a>

</div>

<script>

const menuToggle =
document.getElementById(
'menuToggle'
);

const sidebar =
document.getElementById(
'sidebar'
);

const closeSidebar =
document.getElementById(
'closeSidebar'
);

menuToggle.onclick = () => {

sidebar.classList.add(
'active'
);

}

closeSidebar.onclick = () => {

sidebar.classList.remove(
'active'
);

}

</script>

</body>
</html>