<script>

const menuToggle =
document.getElementById(
'menuToggle'
);

const sidebar =
document.getElementById(
'sidebar'
);

const closeSidebar =
document.getElementById(
'closeSidebar'
);

if(menuToggle){

menuToggle.onclick = () => {

sidebar.classList.add(
'active'
);

}

}

if(closeSidebar){

closeSidebar.onclick = () => {

sidebar.classList.remove(
'active'
);

}

}

</script>

</body>
</html>