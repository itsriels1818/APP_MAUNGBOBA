<?php

include '../config/koneksi.php';

$id =
isset($_GET['id'])
? intval($_GET['id'])
: 0;

$query = mysqli_query($conn,"
SELECT *
FROM pesanan
WHERE id_pesanan='$id'
");

if(mysqli_num_rows($query) == 0){

die("Data pesanan tidak ditemukan");

}

$data = mysqli_fetch_array($query);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Detail Pesanan</title>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<link
rel="stylesheet"
href="../assets/css/admin.css">

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<div>

<div class="logo-box">

<h3>Maung Boba</h3>

<p>Management System</p>

</div>

<ul class="menu-list">

<li>

<a href="index.php">

<i class="bi bi-grid-fill"></i>

Dashboard

</a>

</li>

<li class="active-menu">

<a href="#">

<i class="bi bi-receipt"></i>

Detail Pesanan

</a>

</li>

</ul>

</div>

<div class="text-white">

<h6>Owner Kedai</h6>

<small>Pemilik / Admin</small>

</div>

</div>

<!-- MAIN -->

<div class="main-content">

<!-- TOPBAR -->

<div class="top-header">

<div>

<h2>Detail Pesanan</h2>

<p>
Informasi lengkap pesanan pelanggan
</p>

</div>

<a
href="index.php"
class="btn-website">

Kembali

</a>

</div>

<!-- DETAIL -->

<div class="dashboard-wrapper">

<div class="table-box detail-box">

<div class="detail-header">

<h4>

<i class="bi bi-receipt-cutoff"></i>

Informasi Pesanan

</h4>

</div>

<div class="detail-item">

<span>Nomor Antrian</span>

<p>

#<?php echo $data['nomor_antrian']; ?>

</p>

</div>

<div class="detail-item">

<span>Nama Pemesan</span>

<p>

<?php echo $data['nama_pemesan']; ?>

</p>

</div>

<div class="detail-item">

<span>Total Harga</span>

<p>

Rp
<?php
echo number_format(
$data['total_harga']
);
?>

</p>

</div>

<div class="detail-item">

<span>Status Pesanan</span>

<?php

$class = 'waiting';

if($data['status_pesanan'] == 'diproses'){
$class = 'process';
}

if($data['status_pesanan'] == 'selesai'){
$class = 'done';
}

?>

<span class="status <?php echo $class; ?>">

<?php
echo ucfirst(
$data['status_pesanan']
);
?>

</span>

</div>

<div class="detail-item">

<span>Tanggal Pesanan</span>

<p>

<?php
echo date(
'd M Y H:i',
strtotime($data['tanggal'])
);
?>

</p>

</div>

</div>

</div>
</div>

</body>
</html>